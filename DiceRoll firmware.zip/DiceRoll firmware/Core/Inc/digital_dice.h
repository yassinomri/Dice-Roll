/*
 * digital_dice.hpp
 *
 *  Created on: Nov 3, 2024
 *      Author: 21699
 */


#ifndef INC_DIGITAL_DICE_HPP_
#define INC_DIGITAL_DICE_HPP_

#include "main.h"

#ifdef __cplusplus
class DigitalDice{
private:

    const uint16_t LED_PINS[4] = {GPIO_PIN_12, GPIO_PIN_13, GPIO_PIN_14, GPIO_PIN_15};  // yellow, orange, red, blue
    const uint32_t DEBOUNCE_DELAY = 100;  // ms

    uint8_t currentNumber;
    uint32_t lastButtonPress;

public:
    DigitalDice();
    void update();
    uint8_t rollDice();
    void sendResult(uint8_t number);

private:
    void clearDisplay();
    void displayNumber(uint8_t number);
    bool rollRequested = false;


};
extern DigitalDice digitalDice;
#endif

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /* INC_DIGITAL_DICE_HPP_ */

