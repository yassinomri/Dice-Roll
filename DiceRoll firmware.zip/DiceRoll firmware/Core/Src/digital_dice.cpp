/*
 * digital_dice.cpp
 *
 *  Created on: Nov 3, 2024
 *      Author: 21699
 */




#include "digital_dice.h"
#include "main.h"
#include "usbd_cdc_if.h"
#include <cstdio>
#include <cstring>

extern uint8_t rxBuffer[64];

DigitalDice::DigitalDice() : currentNumber(0), lastButtonPress(0) {
    // Constructor - initialization already done by CubeMX generated code
}

void DigitalDice::clearDisplay() {
    for(int i = 0; i < 4; i++) {
        HAL_GPIO_WritePin(GPIOD, LED_PINS[i], GPIO_PIN_RESET);
    }
}

void DigitalDice::displayNumber(uint8_t number) {
    clearDisplay();

    switch(number) {
        case 1:
            HAL_GPIO_WritePin(GPIOD, LED_PINS[0], GPIO_PIN_SET);  // yellow LED
            break;
        case 2:
            HAL_GPIO_WritePin(GPIOD, LED_PINS[0], GPIO_PIN_SET);  // yellow LED
            HAL_GPIO_WritePin(GPIOD, LED_PINS[1], GPIO_PIN_SET);  // orange LED
            break;
        case 3:
            HAL_GPIO_WritePin(GPIOD, LED_PINS[0], GPIO_PIN_SET);  // yellow LED
            HAL_GPIO_WritePin(GPIOD, LED_PINS[1], GPIO_PIN_SET);  // orange LED
            HAL_GPIO_WritePin(GPIOD, LED_PINS[2], GPIO_PIN_SET);  // red LED
            break;
        case 4:
            HAL_GPIO_WritePin(GPIOD, LED_PINS[0], GPIO_PIN_SET);  // yellow LED
            HAL_GPIO_WritePin(GPIOD, LED_PINS[1], GPIO_PIN_SET);  // orange LED
            HAL_GPIO_WritePin(GPIOD, LED_PINS[2], GPIO_PIN_SET);  // red LED
            HAL_GPIO_WritePin(GPIOD, LED_PINS[3], GPIO_PIN_SET);  // blue LED
            break;
        case 5:
            //blink all LEDs
            for(int i = 0; i < 4; i++) {
                HAL_GPIO_WritePin(GPIOD, LED_PINS[i], GPIO_PIN_SET);
            }
            HAL_Delay(100);
            clearDisplay();
            HAL_Delay(100);
            for(int i = 0; i < 4; i++) {
                HAL_GPIO_WritePin(GPIOD, LED_PINS[i], GPIO_PIN_SET);
            }
            break;
        case 6:
            // rotate LEDs
            for(int i = 0; i < 4; i++) {
                clearDisplay();
                HAL_GPIO_WritePin(GPIOD, LED_PINS[i], GPIO_PIN_SET);
                HAL_Delay(100);
            }
            break;
    }
}

void DigitalDice::update() {
    uint32_t currentTime = HAL_GetTick();

    	//check button with debouncing
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_SET || rxBuffer[0] == 'R') {
        if (currentTime - lastButtonPress > DEBOUNCE_DELAY) {
            uint8_t roll = rollDice();
            lastButtonPress = currentTime;
            sendResult(roll);
            rxBuffer[0] = '\0';
        }
    }
}

uint8_t DigitalDice::rollDice() {
		//simple animation
    for(int i = 0; i < 10; i++) {
        displayNumber((i % 6) + 1);
        HAL_Delay(50 + (i * 20));  //slow down
    }

    //generate random number between 1 and 6
    currentNumber = (HAL_GetTick() % 6) + 1;
    displayNumber(currentNumber);
    return currentNumber;
}


void DigitalDice::sendResult(uint8_t number) {
    uint8_t buffer = static_cast<uint8_t>(number);
    CDC_Transmit_FS(&buffer, 1);
}

DigitalDice digitalDice;

